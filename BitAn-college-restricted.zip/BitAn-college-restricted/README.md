<h1>An anonymous chatting client.</h1>
<h2>To run</h2> 

install node

do npm install

npm run build

node ./server.js
